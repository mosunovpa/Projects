#ifndef _commonutils_h__
#define _commonutils_h__

#ifdef COMMONUTILS_EXPORTS
#define COMMONUTILS_API __declspec(dllexport)
#else
#define COMMONUTILS_API __declspec(dllimport)
#endif

#endif // _commonutils_h__