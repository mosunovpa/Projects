/**
 * \file strutils.h
 *
 * \since 2006/03/17
 * \author pavel
 */

#ifndef strutils_h__
#define strutils_h__

#include "wstring.h"
#include "commonutils.h"


// character type
#if defined(_UNICODE) || defined(UNICODE) || defined(SQLITEPP_UNICODE)
#define ATOT(pStr, len) strutils::toWideString(pStr, len)
#else
#define ATOT(pStr, len) _tstring(pStr, len)
#endif


//////////////////////////////////////////////////////////////////////////
// Conversation functions
//
namespace strutils
{
 	COMMONUTILS_API _tstring guid2string(const GUID& guid);
 	COMMONUTILS_API _tstring format(LPCTSTR fmt, ...);
 	COMMONUTILS_API _tstring to_string(int val, size_t size = 20, int radix = 10);
	COMMONUTILS_API std::wstring toWideString(const char* pStr, int len);
	COMMONUTILS_API std::string toNarrowString(const wchar_t* pStr, int len);
} // namespace strutils

#endif // strutils_h__
