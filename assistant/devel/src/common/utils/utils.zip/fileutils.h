/**
 * \file fileutils.h
 *
 * \since 2006/03/28
 * \author pavel
 */
#ifndef fileutils_h__
#define fileutils_h__

#include "wstring.h"
#include "commonutils.h"

namespace fileutils
{
	COMMONUTILS_API BOOL CreateDirectoryRecursive(LPCTSTR szPath, LPSECURITY_ATTRIBUTES lpSecurityAttributes = NULL);
	COMMONUTILS_API ULONGLONG GetFileSize(LPCTSTR szFilepath);
	COMMONUTILS_API _tstring file_name(LPCTSTR szFilePath);

} // namespace fileutils

#endif // fileutils_h__